#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "publicacion.h"
#include "utn.h"

/** \brief
 * \param array Publicacion*
 * \param limite int
 * \return int
 *
 */
int publicacion_init(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}

int publicacion_mostrarDebug(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - IDPROD: %d - NOMPROD: %s - IDUS: %d - $PROD: %f - STOCK: %d - EST: %d \n",array[i].idProducto, array[i].nombreProd, array[i].idUsuario, array[i].precio, array[i].stock, array[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_mostrar(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("[RELEASE] - %d - %s - %d\n",array[i].idProducto, array[i].nombreProd, array[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_alta(Publicacion* array,int limite, int auxUsuario)
{
    int retorno = -1;
    int i;
    char nombreProd[50];
    float precioProd;
    int auxStock;

    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibrePublicacion(array,limite);
        if(i >= 0)
        {
            if(!getValidString("\nNombre de producto? ","\nNo es un producto VALIDO!","El max caracteres es 40",nombreProd,40,2))
            {
                if(!getValidFloat("Precio de producto", "El precio ingresado es invalido", &precioProd, 0, 99999999,2))
                {
                    if(!getValidInt("Stock","Valor ingresado invalido",&auxStock, 0, 99999, 2))
                    {
                        retorno = 0;
                        strcpy(array[i].nombreProd,nombreProd);
                        array[i].precio = precioProd;
                        array[i].idUsuario = auxUsuario;
                        //------------------------------
                        //------------------------------
                        array[i].idProducto=proximoIdPublicacion();
                        array[i].stock = auxStock;
                        array[i].isEmpty = 0;
                    }


                }

            }
            else
            {
                retorno = -3;
            }
        }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}


int publicacion_baja(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idProducto==id)
            {
                array[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}




int publicacion_modificacion(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    char buffer[50];
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idProducto==id)
            {
                if(!getValidString("\nNombre? ","\nEso no es un nombre","El maximo es 40",buffer,40,2))
                {
                    retorno = 0;
                    strcpy(array[i].nombreProd,buffer);
                    //------------------------------
                    //------------------------------
                }
                else
                {
                    retorno = -3;
                }
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

int publicacion_ordenar(Publicacion* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Publicacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    ///COMPARA CARACTER CON CARACTER SI EL PRIMERO ESTA ANTES EN EL ABC DEVUELVE +
                    ///IGUALES DEVUELVE 0
                    if(( strcmp(array[i].nombreProd, array[i+1].nombreProd) > 0 && orden) || (strcmp(array[i].nombreProd,array[i+1].nombreProd) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

int buscarLugarLibrePublicacion(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


int proximoIdPublicacion()
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}
